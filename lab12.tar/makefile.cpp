//
//  makefile.cpp
//  Bell-Lapadula
//
//  Created by Spencer Browning on 7/13/19.
//  Copyright © 2019 Spencer Browning. All rights reserved.
//

#include <stdio.h>
